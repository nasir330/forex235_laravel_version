<x-header />

<body>
    <x-octa-menu />
    {{-- <x-exness-menu /> --}}
    {{-- <x-menu /> --}}
    <!--ticker tape-->
    @include('templates.tickerTape')


    <!-- deposit and withdrawal card section start  -->
    <div class="container-fluid">
        <div class="row text-right">
            <div class="col-md-12 depositWithdrawalSection align-self-right">
                <h1 class="ml-auto">Deposit and Withdrawal</h1>
            </div>
        </div>
        <div class="row">
            <div class="card-container">
                <div class="box-container">
                    <div class="col box-item">
                        <div class="flip-box">
                            <div class="flip-box-front flipbox-bg text-center">
                                <div class="inner color-white">
                                    <h2 class="flip-box-header">Free Deposit & Withdrawal</h2>
                                    <p><br></p>

                                    <i class="flipboxIcon fa-solid fa-circle-chevron-right"></i>
                                </div>
                            </div>
                            <div class="flip-box-back flipbox-bg text-center">
                                <div class="inner color-white">
                                    <h3 class="flip-box-header">Make Your Deposit</h3>
                                    <p>No hidden charges <br> No Commission</p>

                                    <button class="btn platform-btn">Deposit Now</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col box-item">
                        <div class="flip-box">
                            <div class="flip-box-front flipbox-bg text-center">
                                <div class="inner color-white">
                                    <h2 class="flip-box-header">Perfect Rates</h2>
                                    <p><br></p>

                                    <i class="flipboxIcon fa-solid fa-circle-chevron-right"></i>
                                </div>
                            </div>
                            <div class="flip-box-back flipbox-bg text-center">
                                <div class="inner color-white">
                                    <h3 class="flip-box-header">Calculator</h3>
                                    <p>Convert your currencies <br> on your best choice</p>

                                    <button class="btn platform-btn">Calculate Now</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col box-item">
                        <div class="flip-box">
                            <div class="flip-box-front flipbox-bg text-center">
                                <div class="inner color-white">
                                    <h2 class="flip-box-header">Deposit Bonus</h2>
                                    <p><br></p>

                                    <i class="flipboxIcon fa-solid fa-circle-chevron-right"></i>
                                </div>
                            </div>
                            <div class="flip-box-back flipbox-bg text-center">
                                <div class="inner color-white">
                                    <h3 class="flip-box-header">Deposit Boosting</h3>
                                    <p>Get upto 50% Deposit bonus <br> on your 1st deposit</p>

                                    <button class="btn platform-btn">Deposit Now</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
    <!-- deposit and withdrawal card section end  -->

    <!-- payment method and fees section start  -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 paymentFeesSection">
                <div class="row">
                    <div class="col-md-12 text-center bg-dark text-light m-1">
                        <h1 class="text-uppercase">Payment methods and fees</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-dark table-striped table-bordered text-center">
                            <thead>
                                <tr>
                                    <th style="width:20%;">Method</th>
                                    <th>Minimum amount</th>
                                    <th>Commission</th>
                                    <th>Execution Time</th>
                                </tr>
                            </thead>
                            <tbody class="payments">
                                <tr>
                                    <td style="text-align: center;"> <img class="img-fluid"
                                            src="Assets/images/Binance-pay.webp" alt="crypto funding Binance Pay"></td>
                                    <td>100.00USDT</td>
                                    <td><strong>free</strong></td>
                                    <i class="fa-sharp fa-solid fa-bolt"></i>
                                    <td> <i class="fa-solid fa-bolt text-warning"></i> Instant</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center;"> <img class="img-fluid"
                                            src="Assets/images/skrill-payment.webp" alt="Skrill Payment Wallet"></td>
                                    <td>100.00USDT</td>
                                    <td><strong>free</strong></td>
                                    <td> <i class="fa-solid fa-bolt text-warning"></i> Instant</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center;"> <img class="img-fluid"
                                            src="Assets/images/neteller-payment.webp" alt="Neteller Payment Wallet">
                                    </td>
                                    <td>100.00USDT</td>
                                    <td><strong>free</strong></td>
                                    <td> <i class="fa-solid fa-bolt text-warning"></i> Instant</td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- payment method and fees section end  -->

    <!-- mid footer section start  -->
    @include('templates.midfooter')
    <!-- mid footer section end  -->

    <!-- footer start -->
    @include('templates.pagefooter')
    <!-- footer end -->

    <!-- modal start -->
    <section>
        @include('templates.modal.loginmodal')
        @include('templates.modal.registermodal')
    </section>
    <!-- modal end -->

    <x-footer />

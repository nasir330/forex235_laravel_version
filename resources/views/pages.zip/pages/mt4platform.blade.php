<x-header />

<body>
    <x-octa-menu />
     <!-- marquee start -->
     <div class="row">
        <div class="marqueeSection col-md-12">
            <marquee direction="left">
                We are working hard to meet our deadlines. Our team is dedicated and motivated to achieve our goals. We have a clear plan and are making progress every day. Our efforts are paying off, and we are seeing positive results. We will continue to work diligently to ensure success.
            </marquee>
        </div>
    </div>
    <!-- marquee end -->

    <!-- forex market start  -->
    <section>
        <div class="row p-4">
            <div class="col-md-5 border text-center p-4">
                <h2 class="border-bottom">Forex 235 <br>MT4 Platform</h1>
                    <p class="forex-market">
                        Forex 235's MT4 Terminal redefines trading efficiency with real-time data and advanced tools.
                        Seamlessly execute trades, analyze trends, and manage your portfolio with precision. Experience
                        the power of MT4 in the hands of Forex 235, your gateway to seamless, intuitive, and successful
                        trading in the dynamic world of forex.
                    </p>
            </div>
            <div class="col-md-7 border text-center p-4">
                <img class="img-fluid" src="Assets/images/MetaTrader-4.webp" alt="MetaTrader 4 Terminal">
            </div>
        </div>
    </section>
    <section>
        <div class="row platform-slogan">
            <div class="col-md-6 align-self-center text-center">
                <h2>"MT4 Mastery Unleashed: Empowering Your Trades, Elevating Your Potential in Every Market Move."</h2>
            </div>
            <div class="col-md-6 align-self-center">
                <div class="collapse" id="collapseExample">
                    <div class="row">
                        <div class="col-md-4">
                            <a href="https://play.google.com/store/apps/details?id=net.metaquotes.metatrader4&hl=en&pli=1"
                                target="_blank" class="btn icon-btn">
                                <img class="img-fluid" src="Assets/images/playstore.svg" alt="">
                            </a>
                        </div>
                        <div class="col-md-4">
                            <a href="https://apps.apple.com/us/app/metatrader-4/id496212596" target="_blank"
                                class="btn icon-btn"> <img src="Assets/images/appstore-btn.svg" alt=""></a>
                        </div>
                        <div class="col-md-4">
                            <a href="/Assets/platforms/forex235MT4setup.exe" download="forex235MT4setup.exe"
                                target="_blank" class="btn icon-btn"> <img src="Assets/images/windows.svg"
                                    alt=""></a>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn platform-btn" data-bs-toggle="collapse"
                    data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    Download MT4
                </button>
            </div>
        </div>

    </section>
    <!-- forex market  end -->

    <!-- mid footer start -->
    @include('templates.midfooter')
    <!-- mid footer end -->

    <!-- footer start -->
    @include('templates.pagefooter')
    <!-- footer end -->

    <!-- modal start -->
    <section>
        @include('templates.modal.loginmodal')
        @include('templates.modal.registermodal')
    </section>
    <!-- modal end -->

    <x-footer />
